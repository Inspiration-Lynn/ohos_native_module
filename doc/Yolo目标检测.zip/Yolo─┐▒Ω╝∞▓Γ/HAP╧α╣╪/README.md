bundle name = napi.test

ability name = napi.test.ServiceAbility
